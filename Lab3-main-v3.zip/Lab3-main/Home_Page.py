import streamlit as st

st.set_page_config(
    page_title="NBAStat: Beyond the Box Score",
    page_icon="🏀",
    layout="wide"
)

# Title of App
st.title("Web Development Labs 03 & 04")

# Assignment Data
st.header("CS 1301")
st.subheader("NBAStat, Web Development - Section A")
st.subheader("Audrey Bewley, Kingston Morgan")

# Introduction
st.write("""
Welcome to our Streamlit Web Development app! You can navigate between the pages using the sidebar to the left. The following pages are:

1. **Basketball Data**: Want to inspect every stat for a team, explore any current or past roster player in 2K-style graphs, compare up to 3 players across different teams, or see where players are from? Go here!
2. **Basketball Chat**: Want to talk to a friendly AI that knows a lot about the NBA? Go here!
3. **Basketball Agent**: Want to ask an AI agent analytical questions backed directly by live NBA stats tools? Go here!
""")
