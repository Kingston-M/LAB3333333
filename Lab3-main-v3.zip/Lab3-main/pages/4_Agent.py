import os
import streamlit as st
import pandas as pd
from pydantic_ai import Agent
from nba_api.stats.endpoints import leaguedashteamstats, leaguedashplayerstats

st.set_page_config(page_title="NBAStat | Basketball Agent", page_icon="🤖", layout="wide")

st.title("🤖 Basketball Data Agent (Dataset-Backed AI)")
st.caption("Powered by Pydantic AI + Live NBA Dataset Tools. Ask real analytical questions grounded in actual NBA stats!")

api_key = ""
try:
    if "GOOGLE_API_KEY" in st.secrets and str(st.secrets["GOOGLE_API_KEY"]).strip():
        api_key = str(st.secrets["GOOGLE_API_KEY"]).strip()
except Exception:
    pass

if not api_key:
    api_key = st.sidebar.text_input("Paste Gemini API Key:", type="password", key="agent_key_box").strip()

if api_key:
    os.environ["GOOGLE_API_KEY"] = api_key
    os.environ["GEMINI_API_KEY"] = api_key

season_choice = st.sidebar.selectbox(
    "Dataset Season for Agent:",
    options=["2026-27", "2025-26", "2024-25", "2023-24", "2022-23"],
    index=0
)

@st.cache_data(ttl=3600)
def fetch_player_dataset(season: str) -> pd.DataFrame:
    base = leaguedashplayerstats.LeagueDashPlayerStats(season=season, per_mode_detailed="PerGame").get_data_frames()[0]
    adv = leaguedashplayerstats.LeagueDashPlayerStats(season=season, measure_type_detailed_defense="Advanced").get_data_frames()[0][
        ["PLAYER_ID", "TS_PCT", "USG_PCT", "OFF_RATING", "DEF_RATING", "NET_RATING"]
    ]
    return pd.merge(base, adv, on="PLAYER_ID", how="left")

@st.cache_data(ttl=3600)
def fetch_team_dataset(season: str) -> pd.DataFrame:
    base = leaguedashteamstats.LeagueDashTeamStats(season=season, per_mode_detailed="PerGame").get_data_frames()[0]
    adv = leaguedashteamstats.LeagueDashTeamStats(season=season, measure_type_detailed_defense="Advanced").get_data_frames()[0][
        ["TEAM_ID", "OFF_RATING", "DEF_RATING", "NET_RATING", "TS_PCT", "PACE"]
    ]
    return pd.merge(base, adv, on="TEAM_ID", how="left")

# --- Tool 1 (Data-processing function): Look up player stats ---
def get_player_stats(player_name: str, season: str = "2026-27") -> dict:
    """Look up a specific NBA player's per-game box score and advanced efficiency stats for a given season."""
    df = fetch_player_dataset(season)
    matches = df[df["PLAYER_NAME"].str.contains(player_name, case=False, na=False)]
    if matches.empty:
        return {"error": f"No player found matching '{player_name}' in {season}."}
    row = matches.iloc[0]
    return {
        "player": row["PLAYER_NAME"],
        "team": row["TEAM_ABBREVIATION"],
        "season": season,
        "games_played": int(row["GP"]),
        "ppg": round(float(row["PTS"]), 1),
        "rpg": round(float(row["REB"]), 1),
        "apg": round(float(row["AST"]), 1),
        "spg": round(float(row["STL"]), 1),
        "bpg": round(float(row["BLK"]), 1),
        "tov": round(float(row["TOV"]), 1),
        "pf_total": int(round(float(row["PF"]) * int(row["GP"]))),
        "fg_pct": round(float(row["FG_PCT"]) * 100, 1),
        "fg3_pct": round(float(row["FG3_PCT"]) * 100, 1),
        "ts_pct": round(float(row["TS_PCT"]) * 100, 1),
        "usg_pct": round(float(row["USG_PCT"]) * 100, 1),
        "plus_minus": round(float(row["PLUS_MINUS"]), 1),
    }

# --- Tool 2 (Data-processing function): Find team roster leader for a stat ---
def get_team_stat_leader(team_abbreviation: str, stat_column: str = "PTS", season: str = "2026-27") -> dict:
    """Find the leader on a specific NBA team (e.g., ATL, OKC, MIN, LAL) for a stat column such as PTS, REB, AST, STL, BLK, PF, or TS_PCT."""
    df = fetch_player_dataset(season)
    team_df = df[df["TEAM_ABBREVIATION"].str.upper() == team_abbreviation.upper()].copy()
    if team_df.empty:
        return {"error": f"No players found for team abbreviation '{team_abbreviation}' in {season}."}
    col = stat_column.upper()
    if col not in team_df.columns:
        col = "PTS"
    team_df["TOTAL_PF"] = team_df["PF"] * team_df["GP"]
    sort_col = "TOTAL_PF" if col == "PF" else col
    leader = team_df.sort_values(sort_col, ascending=False).iloc[0]
    val = round(float(leader[sort_col]) * 100, 1) if "PCT" in col else round(float(leader[sort_col]), 1)
    return {
        "team": team_abbreviation.upper(),
        "season": season,
        "stat": col,
        "leader_name": leader["PLAYER_NAME"],
        "value": val,
        "ppg": round(float(leader["PTS"]), 1),
        "rpg": round(float(leader["REB"]), 1),
        "apg": round(float(leader["AST"]), 1),
        "ts_pct": round(float(leader["TS_PCT"]) * 100, 1),
    }

# --- Tool 3 (AI-assisted): Compare two NBA teams ---
def compare_nba_teams(team1_name: str, team2_name: str, season: str = "2026-27") -> dict:
    """Compare two NBA teams across record, PPG, Offensive Rating, Defensive Rating, Net Rating, and True Shooting %."""
    # AI-assisted helper to compare team box score & advanced ratings
    df = fetch_team_dataset(season)
    t1 = df[df["TEAM_NAME"].str.contains(team1_name, case=False, na=False)]
    t2 = df[df["TEAM_NAME"].str.contains(team2_name, case=False, na=False)]
    if t1.empty or t2.empty:
        return {"error": f"Could not find one or both teams: '{team1_name}', '{team2_name}'."}
    r1, r2 = t1.iloc[0], t2.iloc[0]
    return {
        "season": season,
        "team_1": {
            "name": r1["TEAM_NAME"],
            "record": f"{int(r1['W'])}-{int(r1['L'])}",
            "ppg": round(float(r1["PTS"]), 1),
            "off_rating": round(float(r1["OFF_RATING"]), 1),
            "def_rating": round(float(r1["DEF_RATING"]), 1),
            "net_rating": round(float(r1["NET_RATING"]), 1),
            "ts_pct": round(float(r1["TS_PCT"]) * 100, 1),
        },
        "team_2": {
            "name": r2["TEAM_NAME"],
            "record": f"{int(r2['W'])}-{int(r2['L'])}",
            "ppg": round(float(r2["PTS"]), 1),
            "off_rating": round(float(r2["OFF_RATING"]), 1),
            "def_rating": round(float(r2["DEF_RATING"]), 1),
            "net_rating": round(float(r2["NET_RATING"]), 1),
            "ts_pct": round(float(r2["TS_PCT"]) * 100, 1),
        }
    }

# --- Tool 4 (AI-assisted): Compare 2 or 3 players ---
def compare_players_dataset(player1_name: str, player2_name: str, player3_name: str = "", season: str = "2026-27") -> dict:
    """Compare 2 or 3 NBA players side-by-side on scoring volume, playmaking, rebounding, and True Shooting efficiency."""
    # AI-assisted tool comparing up to 3 players from the dataset
    res = {
        "season": season,
        "player_1": get_player_stats(player1_name, season),
        "player_2": get_player_stats(player2_name, season),
    }
    if player3_name.strip():
        res["player_3"] = get_player_stats(player3_name, season)
    return res

def run_data_agent(prompt_text: str, history: list, key: str):
    os.environ["GOOGLE_API_KEY"] = key
    os.environ["GEMINI_API_KEY"] = key
    instructions = (
        "You are the 'NBAStat: Beyond the Box Score' AI Data Analyst. You MUST answer user questions using "
        "the provided NBA dataset tools rather than guessing from memory. Always pass the user's requested season "
        "(or the active sidebar season) into the tool calls. Highlight efficiency metrics like True Shooting % (TS%) "
        "and Net Rating alongside traditional box score stats."
    )
    tools_list = [get_player_stats, get_team_stat_leader, compare_nba_teams, compare_players_dataset]
    last_err = None
    for model_name in ["google-gla:gemini-2.5-flash", "google-gla:gemini-2.0-flash", "gemini-2.5-flash"]:
        try:
            agent = Agent(model_name, tools=tools_list, instructions=instructions)
            return agent.run_sync(prompt_text, message_history=history)
        except Exception as e:
            last_err = e
    raise last_err

st.markdown("**Try asking:**")
sample_cols = st.columns(3)
sample_questions = [
    f"Which Hawks player (ATL) recorded the most personal fouls (PF) in {season_choice}?",
    f"How does the Timberwolves' efficiency compare to the Thunder in {season_choice}?",
    f"Compare Shai Gilgeous-Alexander, Luka Doncic, and Nikola Jokic in {season_choice}."
]
for idx, q in enumerate(sample_questions):
    if sample_cols[idx].button(q, use_container_width=True):
        st.session_state["pending_agent_prompt"] = q

if "agent_messages" not in st.session_state:
    st.session_state.agent_messages = [
        {"role": "assistant", "content": f"🤖 Ready to analyze the **{season_choice}** NBA season! Ask me about any player, team leader, or multi-player comparison."}
    ]
if "agent_history" not in st.session_state:
    st.session_state.agent_history = []

for msg in st.session_state.agent_messages:
    with st.chat_message(msg["role"]):
        if "tool_logs" in msg and msg["tool_logs"]:
            with st.expander("🛠️ Tools Called & Dataset Results"):
                for log in msg["tool_logs"]:
                    st.write(f"**Tool:** `{log['tool']}` | **Args:** `{log['args']}`")
                    st.json(log["result"])
        st.markdown(msg["content"])

typed_input = st.chat_input(f"Ask a data question about the {season_choice} NBA season...")
user_input = st.session_state.pop("pending_agent_prompt", None) or typed_input

if user_input:
    st.session_state.agent_messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        if not api_key:
            err_msg = "⚠️ Please paste your Gemini `GOOGLE_API_KEY` in `.streamlit/secrets.toml` or in the left sidebar to run the NBA Data Agent."
            st.warning(err_msg)
            st.session_state.agent_messages.append({"role": "assistant", "content": err_msg})
        else:
            try:
                contextual_prompt = f"[Active Season: {season_choice}] {user_input}"
                with st.spinner("Querying NBA dataset tools..."):
                    result = run_data_agent(contextual_prompt, st.session_state.agent_history, api_key)

                tool_logs = []
                tool_calls_map = {}
                for m in result.new_messages():
                    for part in getattr(m, "parts", []):
                        part_kind = getattr(part, "part_kind", "")
                        if part_kind == "tool-call":
                            tool_calls_map[part.tool_call_id] = {
                                "tool": part.tool_name,
                                "args": part.args,
                                "result": None
                            }
                        elif part_kind == "tool-return":
                            if part.tool_call_id in tool_calls_map:
                                tool_calls_map[part.tool_call_id]["result"] = part.content
                tool_logs = list(tool_calls_map.values())

                if tool_logs:
                    with st.expander("🛠️ Tools Called & Dataset Results", expanded=True):
                        for log in tool_logs:
                            st.write(f"**Tool:** `{log['tool']}` | **Args:** `{log['args']}`")
                            st.json(log["result"])

                st.markdown(result.output)
                st.session_state.agent_messages.append({
                    "role": "assistant",
                    "content": result.output,
                    "tool_logs": tool_logs
                })
                st.session_state.agent_history = result.all_messages()
            except Exception as e:
                err = f"Agent Error: {e}"
                st.error(err)
                st.session_state.agent_messages.append({"role": "assistant", "content": err})
