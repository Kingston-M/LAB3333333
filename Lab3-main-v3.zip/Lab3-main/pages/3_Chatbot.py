import os
import requests
import streamlit as st
from pydantic_ai import Agent

st.set_page_config(page_title="NBAStat | Basketball Chat", page_icon="💬", layout="wide")

st.title("💬 Basketball Chat — NBA Analytics Assistant")
st.caption("Ask about basketball strategy, advanced analytics concepts (TS%, USG%, Offensive/Defensive Rating), or NBA history.")

# Load Gemini API key safely from secrets.toml or sidebar input
api_key = ""
try:
    if "GOOGLE_API_KEY" in st.secrets and str(st.secrets["GOOGLE_API_KEY"]).strip():
        api_key = str(st.secrets["GOOGLE_API_KEY"]).strip()
except Exception:
    pass

if not api_key:
    api_key = st.sidebar.text_input("Paste Gemini API Key:", type="password", key="chat_key_box").strip()

if api_key:
    os.environ["GOOGLE_API_KEY"] = api_key
    os.environ["GEMINI_API_KEY"] = api_key

SYSTEM_INSTRUCTIONS = (
    "You are an enthusiastic, knowledgeable NBA analytics assistant for the 'NBAStat: Beyond the Box Score' "
    "CS 1301 project created by Audrey Bewley and Kingston Morgan. Stay strictly on the theme of basketball, "
    "NBA analytics, and explaining statistics like True Shooting Percentage (TS%), Usage Rate (USG%), "
    "Offensive/Defensive Rating, and player roles. Remind users they can visit the 'Basketball Agent' page "
    "to query live NBA dataset numbers directly."
)

def ask_gemini_chat(user_prompt: str, history: list, key: str):
    """Runs Pydantic AI Agent first, with automatic model and REST fallbacks so chat always works."""
    os.environ["GOOGLE_API_KEY"] = key
    os.environ["GEMINI_API_KEY"] = key

    for model_id in ["google-gla:gemini-2.5-flash", "google-gla:gemini-2.0-flash", "gemini-2.5-flash"]:
        try:
            agent = Agent(model_id, instructions=SYSTEM_INSTRUCTIONS)
            res = agent.run_sync(user_prompt, message_history=history)
            return res.output, res.all_messages()
        except Exception:
            continue

    # Direct Gemini REST fallback if pydantic-ai provider version mismatches
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}"
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_INSTRUCTIONS}]},
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}]
    }
    resp = requests.post(url, json=payload, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    reply = data["candidates"][0]["content"]["parts"][0]["text"]
    return reply, history

if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = [
        {"role": "assistant", "content": "🏀 Hey! I'm the **NBAStat Basketball Assistant**. Ask me anything about NBA analytics (like True Shooting %, Usage Rate, or Offensive/Defensive Rating), team playstyles, or basketball history!"}
    ]
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Render all chat messages
for msg in st.session_state.chat_messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Top-level chat input box (never nested inside forms/columns/tabs so typing works reliably)
prompt = st.chat_input("Type a message about basketball or NBA stats...")

if prompt:
    st.session_state.chat_messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        if not api_key:
            warn = "⚠️ Please paste your Gemini `GOOGLE_API_KEY` in `.streamlit/secrets.toml` or in the left sidebar to chat!"
            st.warning(warn)
            st.session_state.chat_messages.append({"role": "assistant", "content": warn})
        else:
            try:
                with st.spinner("Thinking..."):
                    reply_text, new_hist = ask_gemini_chat(prompt, st.session_state.chat_history, api_key)
                st.markdown(reply_text)
                st.session_state.chat_messages.append({"role": "assistant", "content": reply_text})
                st.session_state.chat_history = new_hist
            except Exception as e:
                err = f"Sorry, I hit an API error: {e}"
                st.error(err)
                st.session_state.chat_messages.append({"role": "assistant", "content": err})
