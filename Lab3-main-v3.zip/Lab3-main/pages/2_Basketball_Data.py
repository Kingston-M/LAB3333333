import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from nba_api.stats.static import teams
from nba_api.stats.endpoints import (
    leaguedashteamstats,
    leaguedashplayerstats,
    commonteamroster,
    commonplayerinfo,
)
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

st.set_page_config(page_title="NBAStat | Basketball Data", page_icon="📊", layout="wide")

TEAM_COLORS = {
    "ATL": "#E03A3E", "BOS": "#007A33", "BKN": "#000000", "CHA": "#1D1160",
    "CHI": "#CE1141", "CLE": "#860038", "DAL": "#00538C", "DEN": "#0E2240",
    "DET": "#C8102E", "GSW": "#1D428A", "HOU": "#CE1141", "IND": "#002D62",
    "LAC": "#C8102E", "LAL": "#552583", "MEM": "#5D76A9", "MIA": "#98002E",
    "MIL": "#00471B", "MIN": "#0C2340", "NOP": "#0C2340", "NYK": "#006BB6",
    "OKC": "#007AC1", "ORL": "#0077C0", "PHI": "#006BB6", "PHX": "#1D1160",
    "POR": "#E03A3E", "SAC": "#5A2D81", "SAS": "#C4CED4", "TOR": "#CE1141",
    "UTA": "#002B5C", "WAS": "#002B5C"
}

def get_team_logo_url(team_id: int) -> str:
    return f"https://cdn.nba.com/logos/nba/{team_id}/primary/L/logo.svg"

def get_player_headshot_url(player_id: int) -> str:
    return f"https://cdn.nba.com/headshots/nba/latest/1040x760/{player_id}.png"

@st.cache_data(ttl=3600)
def load_team_stats(season: str) -> pd.DataFrame:
    base = leaguedashteamstats.LeagueDashTeamStats(
        season=season,
        per_mode_detailed="PerGame"
    ).get_data_frames()[0]
    adv = leaguedashteamstats.LeagueDashTeamStats(
        season=season,
        measure_type_detailed_defense="Advanced"
    ).get_data_frames()[0][["TEAM_ID", "OFF_RATING", "DEF_RATING", "NET_RATING", "TS_PCT", "PACE", "PIE"]]
    return pd.merge(base, adv, on="TEAM_ID", how="left")

@st.cache_data(ttl=3600)
def load_player_stats(season: str) -> pd.DataFrame:
    base = leaguedashplayerstats.LeagueDashPlayerStats(
        season=season,
        per_mode_detailed="PerGame"
    ).get_data_frames()[0]
    adv = leaguedashplayerstats.LeagueDashPlayerStats(
        season=season,
        measure_type_detailed_defense="Advanced"
    ).get_data_frames()[0][["PLAYER_ID", "TS_PCT", "USG_PCT", "OFF_RATING", "DEF_RATING", "NET_RATING", "PIE"]]
    return pd.merge(base, adv, on="PLAYER_ID", how="left")

@st.cache_data(ttl=3600)
def load_team_roster(team_id: int, season: str) -> pd.DataFrame:
    return commonteamroster.CommonTeamRoster(team_id=team_id, season=season).get_data_frames()[0]

def compute_2k_overall(row: pd.Series) -> int:
    pts = float(row.get("PTS", 0))
    reb = float(row.get("REB", 0))
    ast = float(row.get("AST", 0))
    stl = float(row.get("STL", 0))
    blk = float(row.get("BLK", 0))
    ts = float(row.get("TS_PCT", 0.55)) * 100
    raw = 68 + (pts * 0.52) + (reb * 0.45) + (ast * 0.65) + ((stl + blk) * 1.4) + ((ts - 54) * 0.35)
    return int(max(70, min(99, round(raw))))

def render_2k_team_banner(team_row: pd.Series, season: str):
    tid = int(team_row["TEAM_ID"])
    tname = team_row["TEAM_NAME"]
    abbr = team_row.get("TEAM_ABBREVIATION", "NBA")
    color = TEAM_COLORS.get(abbr, "#1D428A")
    logo = get_team_logo_url(tid)

    html = f"""
    <div style="
        background: linear-gradient(135deg, #0e131f 0%, {color} 100%);
        border: 2px solid #f5c542;
        border-radius: 16px;
        padding: 18px;
        color: white;
        box-shadow: 0 8px 24px rgba(0,0,0,0.45);
        margin-bottom: 16px;
    ">
        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:14px;">
            <div style="display:flex; align-items:center; gap:16px;">
                <img src="{logo}" width="76" height="76" style="object-fit:contain;" />
                <div>
                    <span style="font-size:12px; letter-spacing:1.2px; color:#f5c542; font-weight:800;">{season} TEAM PROFILE</span>
                    <h2 style="margin:2px 0; font-size:26px; font-weight:900;">{tname} ({abbr})</h2>
                    <span style="font-size:14px; color:#e0e0e0;">
                        Record: <b>{int(team_row['W'])}-{int(team_row['L'])}</b> ({team_row['W_PCT']*100:.1f}%) • Net Rating: <b>{team_row['NET_RATING']:+.1f}</b>
                    </span>
                </div>
            </div>
            <div style="display:grid; grid-template-columns: repeat(5, 1fr); gap:10px; background:rgba(0,0,0,0.45); padding:12px; border-radius:12px; text-align:center;">
                <div><div style="font-size:11px; color:#bbb;">PPG</div><div style="font-size:17px; font-weight:800;">{team_row['PTS']:.1f}</div></div>
                <div><div style="font-size:11px; color:#bbb;">OFF RTG</div><div style="font-size:17px; font-weight:800;">{team_row['OFF_RATING']:.1f}</div></div>
                <div><div style="font-size:11px; color:#bbb;">DEF RTG</div><div style="font-size:17px; font-weight:800;">{team_row['DEF_RATING']:.1f}</div></div>
                <div><div style="font-size:11px; color:#bbb;">TS%</div><div style="font-size:17px; font-weight:800; color:#f5c542;">{team_row['TS_PCT']*100:.1f}%</div></div>
                <div><div style="font-size:11px; color:#bbb;">PACE</div><div style="font-size:17px; font-weight:800;">{team_row['PACE']:.1f}</div></div>
            </div>
        </div>
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)

def render_2k_player_card(player_row: pd.Series, team_id: int, team_abbr: str, season: str, roster_meta: dict = None):
    pid = int(player_row["PLAYER_ID"])
    name = player_row["PLAYER_NAME"]
    ovr = compute_2k_overall(player_row)
    color = TEAM_COLORS.get(team_abbr, "#1D428A")
    headshot = get_player_headshot_url(pid)
    logo = get_team_logo_url(team_id)

    pos = roster_meta.get("POSITION", "") if roster_meta else ""
    num = f"#{roster_meta.get('NUM', '')}" if roster_meta and roster_meta.get("NUM") else ""
    badge = f"{pos} {num}".strip()

    card_html = f"""
    <div style="
        background: linear-gradient(145deg, #111625 0%, {color} 100%);
        border: 2px solid #f5c542;
        border-radius: 18px;
        padding: 16px;
        color: white;
        box-shadow: 0 10px 25px rgba(0,0,0,0.45);
        font-family: 'Segoe UI', sans-serif;
        margin-bottom: 12px;
    ">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <div>
                <span style="font-size:32px; font-weight:900; color:#f5c542; line-height:1;">{ovr}</span>
                <span style="font-size:11px; font-weight:700; letter-spacing:1px; color:#ddd; display:block;">OVR • {team_abbr} {badge}</span>
                <span style="font-size:11px; color:#f5c542;">{season}</span>
            </div>
            <img src="{logo}" width="50" height="50" style="object-fit:contain;" />
        </div>
        <div style="text-align:center; margin: 4px 0;">
            <img src="{headshot}" width="160" style="border-radius: 10px; object-fit:cover;" onerror="this.style.display='none'" />
            <h3 style="margin: 6px 0 2px 0; font-size:19px; font-weight:800; color:#ffffff;">{name}</h3>
            <span style="font-size:12px; color:#e0e0e0;">GP: {int(player_row.get('GP', 0))} | MIN: {player_row.get('MIN', 0):.1f} | +/-: {player_row.get('PLUS_MINUS', 0):+.1f}</span>
        </div>
        <div style="
            display:grid; grid-template-columns: repeat(4, 1fr); gap:6px;
            background: rgba(0,0,0,0.45); border-radius:12px; padding:10px; text-align:center; margin-top:8px;
        ">
            <div><div style="font-size:10px; color:#bbb;">PPG</div><div style="font-size:15px; font-weight:800;">{player_row.get('PTS', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">RPG</div><div style="font-size:15px; font-weight:800;">{player_row.get('REB', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">APG</div><div style="font-size:15px; font-weight:800;">{player_row.get('AST', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">TS%</div><div style="font-size:15px; font-weight:800; color:#f5c542;">{player_row.get('TS_PCT', 0)*100:.1f}%</div></div>
            <div><div style="font-size:10px; color:#bbb;">FG%</div><div style="font-size:13px; font-weight:700;">{player_row.get('FG_PCT', 0)*100:.1f}%</div></div>
            <div><div style="font-size:10px; color:#bbb;">3P%</div><div style="font-size:13px; font-weight:700;">{player_row.get('FG3_PCT', 0)*100:.1f}%</div></div>
            <div><div style="font-size:10px; color:#bbb;">FT%</div><div style="font-size:13px; font-weight:700;">{player_row.get('FT_PCT', 0)*100:.1f}%</div></div>
            <div><div style="font-size:10px; color:#bbb;">USG%</div><div style="font-size:13px; font-weight:700;">{player_row.get('USG_PCT', 0)*100:.1f}%</div></div>
            <div><div style="font-size:10px; color:#bbb;">STL</div><div style="font-size:13px; font-weight:700;">{player_row.get('STL', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">BLK</div><div style="font-size:13px; font-weight:700;">{player_row.get('BLK', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">TOV</div><div style="font-size:13px; font-weight:700;">{player_row.get('TOV', 0):.1f}</div></div>
            <div><div style="font-size:10px; color:#bbb;">PF</div><div style="font-size:13px; font-weight:700;">{player_row.get('PF', 0):.1f}</div></div>
        </div>
    </div>
    """
    st.markdown(card_html, unsafe_allow_html=True)

def mapMaking(team, season):
    teamInfo = teams.find_teams_by_full_name(team)
    teamID = teamInfo[0]["id"]
    teamLoc = f"{teamInfo[0]['city']}, {teamInfo[0]['state']}"
    geolocator = Nominatim(user_agent="cs1301_nbaLocations")
    geocode = RateLimiter(geolocator.geocode, min_delay_seconds=1)
    teamCoord = geocode(teamLoc)

    roster_df = load_team_roster(teamID, season)
    playerLats, playerLongs, validPlayers = [], [], []

    for _, r in roster_df.iterrows():
        playerName = r["PLAYER"]
        playerID = r["PLAYER_ID"]
        playerInfo = commonplayerinfo.CommonPlayerInfo(player_id=playerID).get_data_frames()[0]
        lastLoc = str(playerInfo["LAST_AFFILIATION"].values[0]).replace("/", ", ")
        playerCoord = geocode(lastLoc)
        if playerCoord is None:
            country = playerInfo["COUNTRY"].values[0]
            if country:
                playerCoord = geocode(country)
        if playerCoord is not None:
            validPlayers.append(playerName)
            playerLats.append(playerCoord.latitude)
            playerLongs.append(playerCoord.longitude)

    allNames = [team] + validPlayers
    allLats = [teamCoord.latitude] + playerLats
    allLongs = [teamCoord.longitude] + playerLongs
    allTypes = ["Team"] + ["Player"] * len(playerLats)

    worldMap = px.scatter_map(
        lat=allLats, lon=allLongs, text=allNames, color=allTypes,
        color_discrete_sequence=["red", "blue"],
        title=f"{team} Player Hometowns ({season})",
        map_style="carto-darkmatter"
    )
    lineLats, lineLongs = [], []
    for i in range(len(playerLats)):
        lineLats.extend([teamCoord.latitude, playerLats[i], None])
        lineLongs.extend([teamCoord.longitude, playerLongs[i], None])
    lines = px.line_map(lat=lineLats, lon=lineLongs)
    worldMap.add_trace(lines.data[0])
    st.plotly_chart(worldMap, use_container_width=True)

def data():
    st.title("🏀 NBA Analytics: Beyond the Box Score")
    st.caption("Choose any team to inspect all team stats, pick any player on a current or past roster, or compare up to 3 players across different teams.")

    seasons_list = ["2026-27", "2025-26", "2024-25", "2023-24", "2022-23", "2021-22", "2020-21", "2019-20", "2018-19", "2017-18", "2016-17", "2015-16"]
    teamsAPI = teams.get_teams()
    team_name_to_obj = {t["full_name"]: t for t in teamsAPI}
    teamOptions = sorted(list(team_name_to_obj.keys()))

    tab1, tab2, tab3, tab4 = st.tabs([
        "🏆 Team Stats Explorer",
        "🃏 Team Roster & Player Stats (Current & Past)",
        "⚔️ Compare Up to 3 Players (Any Teams)",
        "🌍 Where Are Players From?"
    ])

    # TAB 1: CHOOSE A TEAM -> SEE ALL STATS FROM THAT TEAM
    with tab1:
        st.subheader("Select a Team to View All Team Statistics")
        t1_c1, t1_c2 = st.columns([2, 1])
        with t1_c1:
            selected_team_name = st.selectbox("Choose NBA Team:", options=teamOptions, index=teamOptions.index("Atlanta Hawks"), key="tab1_team")
        with t1_c2:
            team_season = st.selectbox("Select Season:", options=seasons_list, index=0, key="tab1_season")

        try:
            with st.spinner(f"Loading all stats for {selected_team_name} ({team_season})..."):
                team_df = load_team_stats(team_season)
                player_df = load_player_stats(team_season)
        except Exception as e:
            st.error(f"Error fetching NBA API data: {e}")
            return

        t_obj = team_name_to_obj[selected_team_name]
        t_row_df = team_df[team_df["TEAM_ID"] == t_obj["id"]]
        if not t_row_df.empty:
            t_row = t_row_df.iloc[0]
            render_2k_team_banner(t_row, team_season)

            box_metrics = {
                "Points (PPG)": float(t_row["PTS"]),
                "Rebounds (RPG)": float(t_row["REB"]),
                "Assists (APG)": float(t_row["AST"]),
                "Steals (SPG)": float(t_row["STL"]),
                "Blocks (BPG)": float(t_row["BLK"]),
                "Turnovers (TOV)": float(t_row["TOV"]),
                "Personal Fouls (PF)": float(t_row["PF"]),
                "Off Rating": float(t_row["OFF_RATING"]),
                "Def Rating": float(t_row["DEF_RATING"]),
                "Pace": float(t_row["PACE"]),
            }
            pct_metrics = {
                "Win %": round(float(t_row["W_PCT"]) * 100, 1),
                "FG %": round(float(t_row["FG_PCT"]) * 100, 1),
                "3P %": round(float(t_row["FG3_PCT"]) * 100, 1),
                "FT %": round(float(t_row["FT_PCT"]) * 100, 1),
                "True Shooting %": round(float(t_row["TS_PCT"]) * 100, 1),
            }

            g1, g2 = st.columns([3, 2])
            with g1:
                fig_team = go.Figure(go.Bar(
                    x=list(box_metrics.keys()),
                    y=[round(v, 1) for v in box_metrics.values()],
                    text=[round(v, 1) for v in box_metrics.values()],
                    textposition="outside",
                    marker_color=TEAM_COLORS.get(t_obj["abbreviation"], "#1D428A"),
                    name=selected_team_name
                ))
                max_val = max(box_metrics.values())
                fig_team.add_layout_image(dict(
                    source=get_team_logo_url(t_obj["id"]),
                    xref="paper", yref="paper",
                    x=0.98, y=0.98, sizex=0.18, sizey=0.18,
                    xanchor="right", yanchor="top"
                ))
                fig_team.update_layout(
                    title=f"{selected_team_name} — Per-Game & Rating Breakdown ({team_season})",
                    template="plotly_dark",
                    yaxis=dict(range=[0, max_val * 1.25]),
                    height=430
                )
                st.plotly_chart(fig_team, use_container_width=True)

            with g2:
                fig_pct = go.Figure(go.Bar(
                    x=list(pct_metrics.keys()),
                    y=list(pct_metrics.values()),
                    text=[f"{v}%" for v in pct_metrics.values()],
                    textposition="outside",
                    marker_color="#f5c542",
                    name="Shooting & Win %"
                ))
                fig_pct.update_layout(
                    title=f"{selected_team_name} — Efficiency & Shooting Percentages",
                    template="plotly_dark",
                    yaxis=dict(range=[0, 105]),
                    height=430
                )
                st.plotly_chart(fig_pct, use_container_width=True)

            st.markdown(f"### 📋 Complete {team_season} Statistical Breakdown — {selected_team_name}")
            all_team_stats = pd.DataFrame([{
                "Team": t_row["TEAM_NAME"],
                "GP": int(t_row["GP"]),
                "W": int(t_row["W"]),
                "L": int(t_row["L"]),
                "WIN%": f"{t_row['W_PCT']*100:.1f}%",
                "PPG": round(float(t_row["PTS"]), 1),
                "RPG": round(float(t_row["REB"]), 1),
                "OREB": round(float(t_row["OREB"]), 1),
                "DREB": round(float(t_row["DREB"]), 1),
                "APG": round(float(t_row["AST"]), 1),
                "SPG": round(float(t_row["STL"]), 1),
                "BPG": round(float(t_row["BLK"]), 1),
                "TOV": round(float(t_row["TOV"]), 1),
                "PF": round(float(t_row["PF"]), 1),
                "FG%": f"{t_row['FG_PCT']*100:.1f}%",
                "3P%": f"{t_row['FG3_PCT']*100:.1f}%",
                "FT%": f"{t_row['FT_PCT']*100:.1f}%",
                "TS%": f"{t_row['TS_PCT']*100:.1f}%",
                "OFF RTG": round(float(t_row["OFF_RATING"]), 1),
                "DEF RTG": round(float(t_row["DEF_RATING"]), 1),
                "NET RTG": round(float(t_row["NET_RATING"]), 1),
                "PACE": round(float(t_row["PACE"]), 1),
                "+/-": round(float(t_row["PLUS_MINUS"]), 1),
            }])
            st.dataframe(all_team_stats, hide_index=True, use_container_width=True)

            st.markdown(f"### 👥 Full {team_season} Roster Statistics ({selected_team_name})")
            team_players = player_df[player_df["TEAM_ID"] == t_obj["id"]].sort_values("PTS", ascending=False).copy()
            if not team_players.empty:
                roster_table = team_players[[
                    "PLAYER_NAME", "GP", "MIN", "PTS", "REB", "AST", "STL", "BLK", "TOV", "PF",
                    "FG_PCT", "FG3_PCT", "FT_PCT", "TS_PCT", "USG_PCT", "OFF_RATING", "DEF_RATING", "NET_RATING", "PLUS_MINUS"
                ]].copy()
                for c in ["FG_PCT", "FG3_PCT", "FT_PCT", "TS_PCT", "USG_PCT"]:
                    roster_table[c] = (roster_table[c] * 100).round(1).astype(str) + "%"
                st.dataframe(roster_table, hide_index=True, use_container_width=True)

    # TAB 2: CHOOSE TEAM + ANY CURRENT OR PAST ROSTER PLAYER -> SEE ALL STATS
    with tab2:
        st.subheader("Inspect Any Player on a Current or Past Team Roster")
        r_c1, r_c2, r_c3 = st.columns([2, 1, 2])
        with r_c1:
            roster_team = st.selectbox("1. Choose Team:", options=teamOptions, index=teamOptions.index("Los Angeles Lakers"), key="tab2_team")
        with r_c2:
            roster_season = st.selectbox("2. Choose Season (Current or Past):", options=seasons_list, index=0, key="tab2_season")

        r_team_obj = team_name_to_obj[roster_team]
        try:
            with st.spinner(f"Loading {roster_team} ({roster_season}) roster and player stats..."):
                r_df = load_team_roster(r_team_obj["id"], roster_season)
                p_season_df = load_player_stats(roster_season)
        except Exception as e:
            st.error(f"Could not load roster for {roster_team} in {roster_season}: {e}")
            return

        roster_names = r_df["PLAYER"].tolist() if not r_df.empty else p_season_df[p_season_df["TEAM_ID"] == r_team_obj["id"]]["PLAYER_NAME"].tolist()
        with r_c3:
            chosen_player = st.selectbox("3. Choose Player from Roster:", options=roster_names, key="tab2_player")

        p_match = p_season_df[(p_season_df["PLAYER_NAME"] == chosen_player) & (p_season_df["TEAM_ID"] == r_team_obj["id"])]
        if p_match.empty:
            p_match = p_season_df[p_season_df["PLAYER_NAME"] == chosen_player]

        roster_meta = {}
        if not r_df.empty and chosen_player in r_df["PLAYER"].values:
            meta_row = r_df[r_df["PLAYER"] == chosen_player].iloc[0]
            roster_meta = {"POSITION": meta_row.get("POSITION", ""), "NUM": meta_row.get("NUM", "")}

        if not p_match.empty:
            p_row = p_match.iloc[0]
            col_card, col_graph = st.columns([1, 2])
            with col_card:
                render_2k_player_card(p_row, r_team_obj["id"], r_team_obj["abbreviation"], roster_season, roster_meta)

            with col_graph:
                radar_cats = ["Scoring (PTS)", "Playmaking (AST)", "Rebounding (REB)", "Defense (STL+BLK)", "Efficiency (TS%)", "Impact (+/-)"]
                radar_vals = [
                    min(100, round((p_row["PTS"] / 35.0) * 100, 1)),
                    min(100, round((p_row["AST"] / 11.0) * 100, 1)),
                    min(100, round((p_row["REB"] / 14.0) * 100, 1)),
                    min(100, round(((p_row["STL"] + p_row["BLK"]) / 4.0) * 100, 1)),
                    min(100, round((p_row["TS_PCT"] / 0.70) * 100, 1)),
                    min(100, max(10, round(((p_row["PLUS_MINUS"] + 10) / 22.0) * 100, 1))),
                ]
                fig_p_radar = go.Figure(go.Scatterpolar(
                    r=radar_vals,
                    theta=radar_cats,
                    fill="toself",
                    name=chosen_player,
                    line_color="#f5c542"
                ))
                fig_p_radar.update_layout(
                    polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                    title=f"2K Player Archetype Profile — {chosen_player} ({roster_season})",
                    template="plotly_dark",
                    height=340
                )
                st.plotly_chart(fig_p_radar, use_container_width=True)

                p_bar_stats = {
                    "PPG": round(float(p_row["PTS"]), 1),
                    "RPG": round(float(p_row["REB"]), 1),
                    "APG": round(float(p_row["AST"]), 1),
                    "SPG": round(float(p_row["STL"]), 1),
                    "BPG": round(float(p_row["BLK"]), 1),
                    "TOV": round(float(p_row["TOV"]), 1),
                    "PF": round(float(p_row["PF"]), 1),
                    "FG%": round(float(p_row["FG_PCT"]) * 100, 1),
                    "3P%": round(float(p_row["FG3_PCT"]) * 100, 1),
                    "FT%": round(float(p_row["FT_PCT"]) * 100, 1),
                    "TS%": round(float(p_row["TS_PCT"]) * 100, 1),
                    "USG%": round(float(p_row["USG_PCT"]) * 100, 1),
                }
                fig_p_bar = go.Figure(go.Bar(
                    x=list(p_bar_stats.keys()),
                    y=list(p_bar_stats.values()),
                    text=list(p_bar_stats.values()),
                    textposition="outside",
                    marker_color=TEAM_COLORS.get(r_team_obj["abbreviation"], "#1D428A")
                ))
                fig_p_bar.update_layout(
                    title=f"{chosen_player} — Complete Statistical Graph ({roster_season})",
                    template="plotly_dark",
                    yaxis=dict(range=[0, max(p_bar_stats.values()) * 1.25]),
                    height=340
                )
                st.plotly_chart(fig_p_bar, use_container_width=True)

            st.markdown(f"### 📋 Full Season Box Score & Advanced Metrics — {chosen_player} ({roster_season})")
            full_p_df = pd.DataFrame([p_row[[
                "PLAYER_NAME", "TEAM_ABBREVIATION", "AGE", "GP", "W", "L", "MIN",
                "PTS", "FGM", "FGA", "FG_PCT", "FG3M", "FG3A", "FG3_PCT", "FTM", "FTA", "FT_PCT",
                "OREB", "DREB", "REB", "AST", "TOV", "STL", "BLK", "PF",
                "TS_PCT", "USG_PCT", "OFF_RATING", "DEF_RATING", "NET_RATING", "PLUS_MINUS"
            ]]]).copy()
            for pct_col in ["FG_PCT", "FG3_PCT", "FT_PCT", "TS_PCT", "USG_PCT"]:
                full_p_df[pct_col] = (full_p_df[pct_col] * 100).round(1).astype(str) + "%"
            st.dataframe(full_p_df, hide_index=True, use_container_width=True)
        else:
            st.warning(f"{chosen_player} was on the {roster_season} {roster_team} roster ({roster_meta}), but did not record game stats that season.")

    # TAB 3: COMPARE PLAYERS ON DIFFERENT TEAMS (UP TO 3 PLAYERS)
    with tab3:
        st.subheader("Compare Players Across Different Teams (Up to 3 Players)")
        ctrl_c1, ctrl_c2 = st.columns([1, 1])
        with ctrl_c1:
            num_players = int(st.radio("How many players do you want to compare?", ["2", "3"], horizontal=True, key="cmp_num_players"))
        with ctrl_c2:
            cmp_season = st.selectbox("Select Season for Comparison:", options=seasons_list, index=0, key="cmp_season")

        try:
            with st.spinner(f"Loading {cmp_season} league player data..."):
                cmp_player_df = load_player_stats(cmp_season)
        except Exception as e:
            st.error(f"Error loading player comparison dataset: {e}")
            return

        default_cmp_teams = ["Oklahoma City Thunder", "Los Angeles Lakers", "Denver Nuggets"]
        selected_player_entries = []
        p_cols = st.columns(num_players)

        for i in range(num_players):
            with p_cols[i]:
                def_t = default_cmp_teams[i] if default_cmp_teams[i] in teamOptions else teamOptions[i]
                t_choice = st.selectbox(f"Player {i+1} Team:", options=teamOptions, index=teamOptions.index(def_t), key=f"cmp_team_{i}")
                t_obj_i = team_name_to_obj[t_choice]
                t_roster_df = load_team_roster(t_obj_i["id"], cmp_season)
                t_stats_df = cmp_player_df[cmp_player_df["TEAM_ID"] == t_obj_i["id"]].sort_values("PTS", ascending=False)
                p_options = t_stats_df["PLAYER_NAME"].tolist() if not t_stats_df.empty else t_roster_df["PLAYER"].tolist()

                p_choice = st.selectbox(f"Select Player {i+1}:", options=p_options, key=f"cmp_player_{i}")
                p_row_match = t_stats_df[t_stats_df["PLAYER_NAME"] == p_choice]
                if not p_row_match.empty:
                    p_r = p_row_match.iloc[0]
                    meta_i = {}
                    if not t_roster_df.empty and p_choice in t_roster_df["PLAYER"].values:
                        mr = t_roster_df[t_roster_df["PLAYER"] == p_choice].iloc[0]
                        meta_i = {"POSITION": mr.get("POSITION", ""), "NUM": mr.get("NUM", "")}
                    render_2k_player_card(p_r, t_obj_i["id"], t_obj_i["abbreviation"], cmp_season, meta_i)
                    selected_player_entries.append((p_r, t_obj_i))

        if len(selected_player_entries) >= 2:
            st.markdown("### 🎮 2K Multi-Player Interactive Comparison Graphs")
            palette = ["#007AC1", "#FDB927", "#E03A3E"]
            radar_cats = ["Scoring (PTS)", "Playmaking (AST)", "Rebounding (REB)", "Defense (STL+BLK)", "Efficiency (TS%)", "Impact (+/-)"]

            cg1, cg2 = st.columns(2)
            with cg1:
                multi_radar = go.Figure()
                for idx, (pr, tobj) in enumerate(selected_player_entries):
                    r_vals = [
                        min(100, round((pr["PTS"] / 35.0) * 100, 1)),
                        min(100, round((pr["AST"] / 11.0) * 100, 1)),
                        min(100, round((pr["REB"] / 14.0) * 100, 1)),
                        min(100, round(((pr["STL"] + pr["BLK"]) / 4.0) * 100, 1)),
                        min(100, round((pr["TS_PCT"] / 0.70) * 100, 1)),
                        min(100, max(10, round(((pr["PLUS_MINUS"] + 10) / 22.0) * 100, 1))),
                    ]
                    multi_radar.add_trace(go.Scatterpolar(
                        r=r_vals,
                        theta=radar_cats,
                        fill="toself",
                        name=f"{pr['PLAYER_NAME']} ({tobj['abbreviation']})",
                        line_color=palette[idx % len(palette)]
                    ))
                multi_radar.update_layout(
                    polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                    title="2K Archetype Radar Overlay (Up to 3 Players)",
                    template="plotly_dark",
                    height=450
                )
                st.plotly_chart(multi_radar, use_container_width=True)

            with cg2:
                stat_keys = ["PTS", "REB", "AST", "STL", "BLK", "TOV"]
                multi_bar = go.Figure()
                for idx, (pr, tobj) in enumerate(selected_player_entries):
                    y_v = [round(float(pr[k]), 1) for k in stat_keys]
                    multi_bar.add_trace(go.Bar(
                        name=f"{pr['PLAYER_NAME']} ({tobj['abbreviation']})",
                        x=stat_keys,
                        y=y_v,
                        text=y_v,
                        textposition="outside",
                        marker_color=palette[idx % len(palette)]
                    ))
                multi_bar.update_layout(
                    title="Per-Game Box Score Comparison",
                    barmode="group",
                    template="plotly_dark",
                    height=450
                )
                st.plotly_chart(multi_bar, use_container_width=True)

            st.markdown("### 📋 Side-by-Side Full Statistical Comparison Table")
            rows_list = []
            for pr, tobj in selected_player_entries:
                rows_list.append({
                    "Player": pr["PLAYER_NAME"],
                    "Team": tobj["abbreviation"],
                    "2K OVR": compute_2k_overall(pr),
                    "GP": int(pr["GP"]),
                    "MIN": round(float(pr["MIN"]), 1),
                    "PPG": round(float(pr["PTS"]), 1),
                    "RPG": round(float(pr["REB"]), 1),
                    "APG": round(float(pr["AST"]), 1),
                    "SPG": round(float(pr["STL"]), 1),
                    "BPG": round(float(pr["BLK"]), 1),
                    "TOV": round(float(pr["TOV"]), 1),
                    "FG%": f"{pr['FG_PCT']*100:.1f}%",
                    "3P%": f"{pr['FG3_PCT']*100:.1f}%",
                    "FT%": f"{pr['FT_PCT']*100:.1f}%",
                    "TS%": f"{pr['TS_PCT']*100:.1f}%",
                    "USG%": f"{pr['USG_PCT']*100:.1f}%",
                    "OFF RTG": round(float(pr["OFF_RATING"]), 1),
                    "DEF RTG": round(float(pr["DEF_RATING"]), 1),
                    "NET RTG": round(float(pr["NET_RATING"]), 1),
                    "+/-": round(float(pr["PLUS_MINUS"]), 1),
                })
            st.dataframe(pd.DataFrame(rows_list), hide_index=True, use_container_width=True)

    # TAB 4: WHERE ARE PLAYERS FROM?
    with tab4:
        st.subheader("Where are players from?")
        map_season = st.selectbox("Select Season for Roster Map:", options=seasons_list, index=0, key="map_season")
        with st.form("mapForm"):
            team = st.selectbox("Choose team:", options=teamOptions)
            submitted = st.form_submit_button("Submit Choice")
        if submitted:
            with st.spinner("Searching the world for players..."):
                mapMaking(team, map_season)
            st.success("Map complete!")

data()
